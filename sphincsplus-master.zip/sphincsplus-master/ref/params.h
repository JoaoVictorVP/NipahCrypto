#define str(s) #s
#define xstr(s) str(s)

#include xstr(params/params-PARAMS.h)

